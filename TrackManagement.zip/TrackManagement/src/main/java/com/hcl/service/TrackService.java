package com.hcl.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.hcl.entities.Track;
import com.hcl.repository.TrackRepository;

@Service
public class TrackService {
	
	@Autowired
	private TrackRepository trackRepository;
	
	public Track createTrackList(Track track){
		return trackRepository.save(track);
	}
	
	public List<Track>getAllTrack(){
		return trackRepository.findAll();
	}
	
	public void deleteById(Long id){
		 trackRepository.deleteById(id);
	}
	

    public List<Track> getTracksSortedByTitle() {
        return trackRepository.findAll()
                .stream()
                .sorted((a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()))
                .toList();
    }


}
