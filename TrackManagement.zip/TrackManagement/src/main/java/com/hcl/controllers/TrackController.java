package com.hcl.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.entities.Track;
import com.hcl.service.TrackService;

@RestController
@RequestMapping("/music/platform/v1/tracks")
public class TrackController {
	
	@Autowired
	private TrackService trackService;
	
	@PostMapping("/create")
	public ResponseEntity<Track>createTrackList(@RequestBody Track track){
		Track createTrack=trackService.createTrackList(track);
		return ResponseEntity.status(HttpStatus.CREATED).body(createTrack);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Track>>getAllT(){
		List<Track> tracks=trackService.getAllTrack();
		return ResponseEntity.ok(tracks);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void>deleteById(@PathVariable Long id){
		 trackService.deleteById(id);
		 return ResponseEntity.noContent().build();
	}
	
	@GetMapping("/getsorted")
	public ResponseEntity<List<Track>>getBySortByTitle(){
		List<Track> sortByTitle=trackService.getTracksSortedByTitle();
		return ResponseEntity.ok(sortByTitle);
	}

}
