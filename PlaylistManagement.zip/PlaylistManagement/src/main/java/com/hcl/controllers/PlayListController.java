package com.hcl.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.entities.PlayList;
import com.hcl.services.PlayListService;

@RestController
@RequestMapping("/v1/playlists")
public class PlayListController {
	
	@Autowired
	private PlayListService playListService;
	
	@PostMapping("/create")
	public ResponseEntity<PlayList> cratePlayList(@RequestBody PlayList playList){
		PlayList createPlayList=playListService.createPlayList(playList);
		return ResponseEntity.status(201).body(createPlayList);
	}
	
	@GetMapping("/getall")
	public ResponseEntity<List<PlayList>>getAllPlayList(@RequestBody PlayList playList){
		return ResponseEntity.ok(playListService.getAllPlayList());
	}
	
	@GetMapping("/getbyId/{id}")
	public ResponseEntity<Optional<PlayList>> getByid(@PathVariable Long id,@RequestBody PlayList playList){
	    Optional<PlayList> byIdplayList = playListService.getAllById(id);
	        return ResponseEntity.ok(byIdplayList);
	}
	
	@GetMapping("/deleteId/{id}")
	public ResponseEntity<Void>deleteById(@PathVariable long id){
		((PlayListService) playListService).deleteById(id);
		return ResponseEntity.noContent().build();
	}

}
