package com.hcl.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.entities.PlayList;
import com.hcl.repository.PlayListRepository;

@Service
public class PlayListService {
	
	@Autowired
	private PlayListRepository playListRepository;

	public PlayList createPlayList(PlayList playList) {
		return playListRepository.save(playList);
	}
	
	public List<PlayList>getAllPlayList(){
		return playListRepository.findAll();
	}
	
	public Optional<PlayList>getAllById(Long id){
		return playListRepository.findById(id);
	}
	
	public void deleteById(Long id) {
		playListRepository.deleteById(id);
	}

	
	
}
