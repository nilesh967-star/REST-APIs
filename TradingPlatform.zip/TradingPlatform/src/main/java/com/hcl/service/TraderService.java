package com.hcl.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.entities.Trader;
import com.hcl.repository.TraderRepository;

@Service
public class TraderService {

	@Autowired
	private TraderRepository traderRepository;

	public Optional<Trader> findByEmail(String email) {
		return traderRepository.findByEmail(email);
	}

	public Boolean existsEmail(String email) {
		return traderRepository.existsByEmail(email);
	}

	public Trader registerTrader(Trader trader) {
		trader.setCreatedAt(LocalDateTime.now());
		trader.setUpdatedAt(null);
		return traderRepository.save(trader);
	}

	public List<Trader> getallTrader() {
		return traderRepository.findAll();
	}

	public Trader updateNameByEmail(String email, Trader trader) {
		Trader existingTrader = traderRepository.findByEmail(email).orElseThrow();
		existingTrader.setName(trader.getName());
		existingTrader.setUpdatedAt(LocalDateTime.now());
		return traderRepository.save(existingTrader);
	}

	public Trader addBalenceByEmail(String email, Trader trader) {
		Optional<Trader> trader1 = traderRepository.findByEmail(email);
		if (trader1.isPresent()) {
			Trader trader2 = trader1.get();
			trader2.setBalence(trader.getBalence());
			trader2.setUpdatedAt(LocalDateTime.now());

			return traderRepository.save(trader2);
		} else {
			return null;
		}
	}

}
