package com.hcl.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.entities.Trader;

public interface TraderRepository extends JpaRepository<Trader, Long> {
	
	Optional<Trader>findByEmail(String email);
	boolean existsByEmail(String email);
	

}
